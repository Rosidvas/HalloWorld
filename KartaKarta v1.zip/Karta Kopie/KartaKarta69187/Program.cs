﻿using System;
using System.Linq;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Timers;
using Figgle;
using System.Diagnostics;
using System.Threading;

namespace KartaKarta69187
{
    class Program
    {
        static void CheckHighscore(int mistake)
        {
            string path = @"..\..\..\Highscoretext.txt";
            string text = File.ReadAllText(path);
            int highscore = Convert.ToInt32(text);
            string score2 = Convert.ToString(highscore);

            if (mistake < highscore)
            {
                try
                {
                    using (FileStream fs = File.Create(path))
                    {
                        byte[] info = new UTF8Encoding(true).GetBytes(score2);
                        fs.Write(info, 0, info.Length);
                    }
                    using (StreamReader sr = File.OpenText(path))
                    {
                        string s = "";
                        while ((s = sr.ReadLine()) != null)
                        {
                            Console.WriteLine("Your score is:");
                            Console.WriteLine("" + mistake + "");
                            Console.WriteLine("Your new highscore is:");
                            Console.WriteLine(s);
                        }

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
            else
            {
                Console.WriteLine("Deine Fehleranzahl:");
                Console.WriteLine("" + mistake + "");
                Console.WriteLine("In deiner besten Runde hattest du < " + highscore + " > Fehler.\n");
            }
        }
        

        static void IntroText()
        {
            string ostrich = @"
                                __
                               (oo)
                                \/
                                ||
                                ||
                                ||,-v-,_
                                ||\ |   /
                            _,''  ''-,-<
                           / :       /  \
                          ( :       (   /,
                           \_;       \ __)
                              \,_ ,   |
                              |  / \  |
                              | /   \ |
                              ()     ()
                              //     ||
                             //      ||
                            //       ||
              -- '' -'-'  ,//        /\   -- '' -'-'   miK
                          ^^         '^^
                ";

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(FiggleFonts.Standard.Render("KartaKarta 69187"));
            Console.ResetColor();
            Console.WriteLine("\nDieses Programm wurde von Vin, Randon, Florian und Matteo gemacht.");
            Console.WriteLine("Team Ostrich, Klasse I21v, 2021.");
            Console.WriteLine("\nKartaKarta 69187 ist ein Karteikartenspiel und hilft dir englische, sowie auch deutsch Wörter zu lernen.");
            Console.WriteLine("Achte aber darauf, dass alle Wörter klein oder gross geschrieben sind.");
            Console.WriteLine("\n\nDrücke eine beliebige Taste um KartaKarta zu starten!\n\n");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(ostrich);
            Console.ResetColor();
        }
        static void OutroText()
        {
            Console.WriteLine("\n\n\nDanke fürs Spielen!");
            Console.WriteLine("\n\nDrücke beliebige Taste zum verlassen.\n\n\n");
            string ninja = @"
            ████                                                                
          ██▒▒██                                                          ██████
        ██░░██                                                      ░░████  ░░██
        ██  ██                                                    ██▓▓  ▒▒████  
        ██░░██                                                ████  ░░░░██      
      ██  ░░██                                              ██    ████▒▒        
      ██  ██                      ██████                  ██  ░░████            
      ██  ██                    ██▒▒▒▒▒▒██        ████  ██  ░░██                
      ██  ██            ██████████▒▒▒▒▒▒██        ██▒▒██░░░░██                  
      ██  ██          ██▒▒▒▒▒▒▒▒▒▒██▒▒▒▒██        ██▒▒██░░██                    
    ██  ░░██        ██▒▒▒▒▒▒▒▒▒▒▒▒▒▒██▒▒██      ██████▒▒██                      
    ██  ░░██      ██▒▒██████████▒▒▒▒▒▒██▒▒██    ██    ████                      
    ██  ██        ████░░░░░░░░░░██▒▒▒▒██████  ██▒▒██  ████                      
    ██  ██        ██░░        ░░▒▒██▒▒██    ██▒▒████  ██                        
    ██  ██        ████        ██  ██▒▒██  ██▒▒██  ██  ██                        
    ██  ██        ██  ██    ██▒▒  ██▒▒██  ████    ██  ██                        
    ██  ██        ██  ░░          ██▒▒██          ██  ██                        
    ██  ██        ██░░        ░░░░██▒▒██        ██    ██                        
    ██  ██        ██░░  ▒▒▒▒  ░░▓▓▒▒██          ██  ░░██                        
    ██░░██          ██  ▓▓▓▓  ░░██▒▒████████████▓▓  ██▓▓                        
    ██░░██            ▓▓████████░░░░░░    ░░░░░░░░░░██                          
    ██░░██          ██  ░░░░░░░░          ░░░░██████                            
████████████▓▓      ██    ░░  ░░      ████████      ░░              ░░          
██▒▒▒▒▓▓▓▓▒▒██░░  ░░██░░░░░░░░░░░░░░░░▓▓  ░░  ░░░░░░░░░░░░░░    ░░  ░░  ░░      
██▓▓▒▒▒▒▒▒▒▒▓▓  ░░▒▒▓▓░░░░░░  ░░  ░░  ██░░  ░░      ░░  ░░        ░░░░░░        
    ██████  ░░  ░░██  ▒▒██░░  ░░░░▒▒▒▒██░░      ░░  ░░      ░░░░    ░░░░        
  ████████    ████░░░░██  ████████████▒▒██  ░░░░░░  ░░░░  ░░░░  ░░  ░░  ░░      
  ██  ░░░░████░░░░  ░░██  ██░░░░░░░░░░░░██                                      
  ██    ██    ░░░░████      ██░░░░░░░░░░██                                      
    ██████████████          ██▓▓████████▓▓██                                    
    ██▒▒██              ████▒▒▒▒▒▒▒▒▒▒▒▒▓▓██                                    
    ██▒▒██            ██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓██                                    
    ██▒▒██          ██▒▒▒▒▒▒▒▒▒▒▓▓▓▓▒▒▒▒▓▓██                                    
      ██          ██▒▒▒▒▒▒▒▒▓▓████▓▓▒▒▒▒▓▓██                                    
                ██▒▒▒▒▒▒▒▒▓▓██  ██▓▓▒▒▒▒▓▓██                                    
                ██▒▒▒▒▒▒▓▓██    ██▓▓▒▒▒▒▓▓██                                    
                ██▒▒▓▓▓▓██      ██▓▓▒▒▒▒▓▓▓▓████                                
                ██▒▒▒▒▓▓██        ██▒▒▒▒▓▓▓▓▓▓▓▓████                            
                ██▒▒▒▒▓▓▓▓██      ██▒▒▓▓▓▓▓▓▓▓▓▓▓▓██                            
                ██▒▒▒▒▓▓▓▓██        ██▒▒▓▓▓▓▓▓▓▓██                              
                ██▒▒▓▓▓▓▓▓▓▓██        ██▒▒▓▓▓▓▓▓████                            
                ██████████████          ██▓▓▓▓██░░░░██                          
                  ██░░░░██                ██▒▒████  ░░██                        
                  ██░░▓▓░░                ░░██░░░░▓▓▓▓▓▓▓▓                      
                  ██░░██                          ██▓▓▓▓██                      
              ██████████                          ██▓▓██                        
            ██▒▒▒▒▓▓▓▓██                        ██▒▒▒▒██                        
            ████████████                        ██████                          
            ";
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(ninja);
            Console.ResetColor();
            Console.Read();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("<3");
            Console.ResetColor();
        }




        static void Main(string[] args)
        {

            IntroText();

            Console.ReadKey();
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(FiggleFonts.Slant.Render("AND GO!"));
            Console.ResetColor();
            Console.WriteLine("\n\n\n\n");

            string[] reader2 = System.IO.File.ReadAllLines(@"..\..\..\English.txt");
            List<string> EnglishList = new List<string>();
            for (int i = 0; i < 50; i++)
            {
                EnglishList.Add(reader2[i]);
            }

            string[] reader1 = System.IO.File.ReadAllLines(@"..\..\..\German.txt");
            List<string> GermanList = new List<string>();
            for (int i = 0; i < 50; i++)
            {
                GermanList.Add(reader1[i]);
            }

            Console.WriteLine("Willst du Karteikarten (1) spielen oder Raten (2)?");
            string response = Console.ReadLine();
            if (response == "1")
            {

                Console.WriteLine("Wollen sie Deutsche (1) oder Englische (2) Wörter übersetzen?[1/2]");
                string language = Console.ReadLine();

                bool isFinished = false;

                while (isFinished == false)
                {
                    if (language == "1")
                    {
                        bool loopWords = true;
                        int mistake = 0;
                        while (loopWords)
                        {
                            int RandomOfList = new Random().Next(1, GermanList.Count);

                            if (GermanList.Count == 1 || EnglishList.Count == 1)
                            {
                                loopWords = false;
                            }
                            else
                            {
                                try
                                {
                                    Console.WriteLine("Deutsch: " + GermanList[RandomOfList]);
                                    Console.WriteLine("English: ");
                                    string guessWord = Reader.ReadLine(10000);

                                    if (guessWord == EnglishList[RandomOfList])
                                    {
                                        Console.ForegroundColor = ConsoleColor.Green;
                                        Console.WriteLine("Richtig!");
                                        Console.ResetColor();
                                        Console.WriteLine("Das Wort " + GermanList[RandomOfList] + " ist " + EnglishList[RandomOfList] + "!\n");
                                        GermanList.Remove(GermanList[RandomOfList]);
                                        EnglishList.Remove(EnglishList[RandomOfList]);
                                    }
                                    else if (guessWord != EnglishList[RandomOfList])
                                    {
                                        mistake++;
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        Console.WriteLine("Falsch!");
                                        Console.ResetColor();
                                        Console.WriteLine("Das Wort war " + EnglishList[RandomOfList] + "\n");
                                    }
                                }
                                catch(TimeoutException) 
                                {
                                    mistake++;
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("\nZeit ist vorbei!");
                                    Console.ResetColor();
                                    Console.WriteLine("Das Wort war " + EnglishList[RandomOfList] + "\n");
                                }
                            }



                        }
                        CheckHighscore(mistake);

                        Console.WriteLine("Willst du es nochmal spielen?[y/n]");
                        string input = Console.ReadLine();
                        if (input == "n")
                        {
                            isFinished = true;
                        }
                    }
                    else if (language == "2")
                    {
                        bool loopWords = true;
                        int mistake = 0;
                        while (loopWords)
                        {

                            int RandomOfList = new Random().Next(1, GermanList.Count + 1);

                            if (EnglishList.Count == 0 || GermanList.Count == 0)
                            {
                                loopWords = false;
                            }
                            else
                            {
                                try
                                {
                                    Console.WriteLine("English: " + EnglishList[RandomOfList]);
                                    Console.WriteLine("Deutsch: ");
                                    string guessWord = Reader.ReadLine(10000);

                                    if (guessWord == GermanList[RandomOfList])
                                    {
                                        Console.ForegroundColor = ConsoleColor.Green;
                                        Console.WriteLine("Richtig!");
                                        Console.ResetColor();
                                        Console.WriteLine("Das Wort " + GermanList[RandomOfList] + " ist " + EnglishList[RandomOfList] + "!\n");
                                        GermanList.Remove(GermanList[RandomOfList]);
                                        EnglishList.Remove(EnglishList[RandomOfList]);

                                    }
                                    else if (guessWord != GermanList[RandomOfList])
                                    {
                                        mistake++;
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        Console.WriteLine("Falsch!");
                                        Console.ResetColor();
                                        Console.WriteLine("Das Wort war " + GermanList[RandomOfList]);
                                    }
                                }
                                catch (TimeoutException)
                                {
                                    mistake++;
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("\nZeit ist vorbei!");
                                    Console.ResetColor();
                                    Console.WriteLine("Das Wort war " + GermanList[RandomOfList] + "\n");
                                }
                            }
                        }
                        CheckHighscore(mistake);

                        Console.WriteLine("Willst du es nochmal spielen?[y/n]");
                        string input = Console.ReadLine();
                        if (input == "n")
                        {
                            isFinished = true;
                        }
                    }

                }
            }
            else
            {
                bool keepAsking = true;
                int mistake = 0;
                while (keepAsking)
                {
                    if (EnglishList.Count == 2 || GermanList.Count == 2)
                    {
                        keepAsking = false;
                    }

                    int randomNum = new Random().Next(1,3);
                    int random2 = new Random().Next(1, EnglishList.Count);
                    if (randomNum == 1)
                    {
                        Console.WriteLine("Heisst " + EnglishList[random2] + " wirklich " + GermanList[random2] + "? [y|n]");
                        string input = Console.ReadLine();
                        if (input == "y")
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Richtig!");
                            Console.ResetColor();

                            EnglishList.Remove(EnglishList[random2]);
                            GermanList.Remove(GermanList[random2]);
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Falsch!");
                            mistake++;
                            Console.ResetColor();
                        }
                    }
                    if (randomNum != 1)
                    {
                        int random3 = new Random().Next(1, EnglishList.Count);
                        while (random3 == random2)
                        {
                            random3 = new Random().Next(1, EnglishList.Count);
                        }

                        Console.WriteLine("Heisst " +EnglishList[random2] + " wircklich "+ GermanList[random3] + "? [y|n]");
                        string input = Console.ReadLine();

                        if (input == "n")
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Richtig!");
                            Console.ResetColor();

                            EnglishList.Remove(EnglishList[random2]);
                            GermanList.Remove(GermanList[random2]);
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Falsch!");
                            mistake++;
                            Console.ResetColor();
                        }
                    }
                }
                Console.WriteLine("Du hast es geschafft! Du bist alle Wörter durch und hattest < " + mistake +" > Fehler!\n\n\n");
                Console.WriteLine("\n\nDrücke eine beliebige Taste zum verlasssen");
                Console.ReadKey();
            }
            Console.Clear();
            OutroText();
        }

        private static Task HandleTimer()
        {
            Console.WriteLine("\nHandler not implemented...");
            throw new NotImplementedException();
        }

    }
    class Reader
    {
        private static Thread inputThread;
        private static AutoResetEvent getInput, gotInput;
        private static string input;
        static Reader()
        {
            getInput = new AutoResetEvent(false);
            gotInput = new AutoResetEvent(false);
            inputThread = new Thread(reader);
            inputThread.IsBackground = true;
            inputThread.Start();
        }
        private static void reader()
        {
            while (true)
            {
                getInput.WaitOne();
                input = Console.ReadLine();
                gotInput.Set();
            }
        }
        public static string ReadLine(int timeOutMillisecs = Timeout.Infinite)
        {
            getInput.Set();
            bool success = gotInput.WaitOne(timeOutMillisecs);
            if (success)
                return input;
            else
                throw new TimeoutException("User did not provide input within the timelimit.");
        }
    }
}